import { Injectable, Component, OnInit } from '@angular/core';
import {ApolloClient} from 'apollo-client';
import {ApolloModule} from 'apollo-angular';
import {HttpLink} from 'apollo-angular-link-http';
import {InMemoryCache} from 'apollo-cache-inmemory';
import gql from 'graphql-tag';
import { Course, Query } from '../types';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Apollo } from 'apollo-angular';

@Injectable({
  providedIn: 'root'
})
export class Tab2Page implements OnInit{
  courses: Observable<Course[]>;
  constructor(private apollo: Apollo) { }
  ngOnInit() {
    this.courses = this.apollo.watchQuery<Query>({
      query: gql`
        query allCourses {
          allCourses {
            id
            title
            author
            description
            topic
            url
          }
        }
      `
    })
      .valueChanges
      .pipe(
        map(result => result.data.allCourses)
      );
  }
}
