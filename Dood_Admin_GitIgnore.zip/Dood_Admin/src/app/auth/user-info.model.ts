// User info is completely independent of what you have set up for your server
export interface IUserInfo {
  display_name: string;
  role: string;
  email: string;
  user_name: string;
}
